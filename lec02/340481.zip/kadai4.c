#include <stdio.h>

int main()
{
    int c, nc;
    
    while((c = getchar()) != EOF) {
        nc++;
        if (nc % 2) {
            putchar(c);
        }
    }
    return 0;
}
